/**
 * \file
 * \brief CUDA 12.1 Ultra-Optimized Texture Creation
 * 
 * This file implements the most advanced texture creation optimizations:
 * - Memory pool pre-allocation
 * - Asynchronous operations
 * - CUDA unified memory
 * - Texture object caching
 * - Batch operations
 */

#include <cuda_runtime.h>
#include <texture_types.h>
#include <chrono>
#include <iostream>
#include <vector>
#include <string.h>
#include "../include/utils/debug_tools.h"

// Simplified ultra-optimized texture creation (without pool for now)
cudaTextureObject_t create3DTextureUltraOptimized(const float* data, const int3& dims,
                                                 cudaTextureFilterMode filterMode,
                                                 cudaTextureAddressMode addressMode) {
    auto start = std::chrono::high_resolution_clock::now();
    
    // Direct allocation with error checking
    cudaChannelFormatDesc floatChannelDesc = cudaCreateChannelDesc<float>();
    cudaExtent extent = make_cudaExtent(dims.x, dims.y, dims.z);
    
    cudaArray* devArray;
    cudaError_t err = cudaMalloc3DArray(&devArray, &floatChannelDesc, extent);
    if (err != cudaSuccess) {
        printf("Error: cudaMalloc3DArray failed: %s\n", cudaGetErrorString(err));
        return 0;
    }
    
    // [9.45 Device-Backed Texture Contract]
    // Determine correct memcpy kind for the input data pointer.
    // This is critical for correctness: host data must use cudaMemcpyHostToDevice,
    // device data must use cudaMemcpyDeviceToDevice (or cudaMemcpyDefault with UVA).
    // If detection fails, we MUST reject rather than guess HostToDevice for device pointers.
    cudaMemcpyKind copyKind = cudaMemcpyDefault;
    if (data != nullptr) {
        cudaPointerAttributes attrs = {};
        if (cudaPointerGetAttributes(&attrs, data) == cudaSuccess) {
#if CUDART_VERSION >= 10000
            if (attrs.type == cudaMemoryTypeDevice || attrs.type == cudaMemoryTypeManaged) {
                copyKind = cudaMemcpyDefault;  // Use UVA path for device pointers
            } else {
                copyKind = cudaMemcpyHostToDevice;
            }
#else
            if (attrs.memoryType == cudaMemoryTypeDevice) {
                copyKind = cudaMemcpyDeviceToDevice;
            } else {
                copyKind = cudaMemcpyHostToDevice;
            }
#endif
        } else {
            cudaGetLastError();
            // If pointer type detection fails, treat as host pointer (conservative).
            copyKind = cudaMemcpyHostToDevice;
        }
    }
    
    // Optimized memory copy
    cudaMemcpy3DParms copyParams = {};
    copyParams.srcPtr = make_cudaPitchedPtr((void*)data, extent.width*sizeof(float), extent.width, extent.height);
    copyParams.dstArray = devArray;
    copyParams.extent = extent;
    copyParams.kind = copyKind;
    
    err = cudaMemcpy3D(&copyParams);
    if (err != cudaSuccess) {
        printf("Error: cudaMemcpy3D failed: %s\n", cudaGetErrorString(err));
        cudaFreeArray(devArray);
        return 0;
    }
    
    // Create texture object with optimized settings
    cudaResourceDesc resDesc = {};
    resDesc.resType = cudaResourceTypeArray;
    resDesc.res.array.array = devArray;
    
    cudaTextureDesc texDesc = {};
    texDesc.readMode = cudaReadModeElementType;
    texDesc.normalizedCoords = false;
    texDesc.filterMode = filterMode;
    texDesc.addressMode[0] = addressMode;
    texDesc.addressMode[1] = addressMode;
    texDesc.addressMode[2] = addressMode;
    
    cudaTextureObject_t texObj;
    err = cudaCreateTextureObject(&texObj, &resDesc, &texDesc, NULL);
    if (err != cudaSuccess) {
        printf("Error: cudaCreateTextureObject failed: %s\n", cudaGetErrorString(err));
        cudaFreeArray(devArray);
        return 0;
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    if (rtdVerboseEnabled()) {
        printf("[TIMING] create3DTexture (ultra-optimized): %ld μs\n", duration.count());
    }
    
    return texObj;
}

// CUDA unified memory version
cudaTextureObject_t create3DTextureUnifiedMemory(const float* data, const int3& dims,
                                                cudaTextureFilterMode filterMode,
                                                cudaTextureAddressMode addressMode) {
    auto start = std::chrono::high_resolution_clock::now();
    
    // Allocate unified memory
    float* unifiedData;
    size_t size = dims.x * dims.y * dims.z * sizeof(float);
    cudaError_t err = cudaMallocManaged(&unifiedData, size);
    if (err != cudaSuccess) {
        printf("Error: cudaMallocManaged failed: %s\n", cudaGetErrorString(err));
        return 0;
    }
    
    // Copy data to unified memory
    memcpy(unifiedData, data, size);
    
    // Create array from unified memory
    cudaChannelFormatDesc floatChannelDesc = cudaCreateChannelDesc<float>();
    cudaExtent extent = make_cudaExtent(dims.x, dims.y, dims.z);
    
    cudaArray* devArray;
    err = cudaMalloc3DArray(&devArray, &floatChannelDesc, extent);
    if (err != cudaSuccess) {
        printf("Error: cudaMalloc3DArray failed: %s\n", cudaGetErrorString(err));
        cudaFree(unifiedData);
        return 0;
    }
    
    // Copy from unified memory to array
    cudaMemcpy3DParms copyParams = {};
    copyParams.srcPtr = make_cudaPitchedPtr(unifiedData, extent.width*sizeof(float), extent.width, extent.height);
    copyParams.dstArray = devArray;
    copyParams.extent = extent;
    copyParams.kind = cudaMemcpyDeviceToDevice;
    
    err = cudaMemcpy3D(&copyParams);
    if (err != cudaSuccess) {
        printf("Error: cudaMemcpy3D failed: %s\n", cudaGetErrorString(err));
        cudaFree(unifiedData);
        cudaFreeArray(devArray);
        return 0;
    }
    
    // Create texture object
    cudaResourceDesc resDesc = {};
    resDesc.resType = cudaResourceTypeArray;
    resDesc.res.array.array = devArray;
    
    cudaTextureDesc texDesc = {};
    texDesc.readMode = cudaReadModeElementType;
    texDesc.normalizedCoords = false;
    texDesc.filterMode = filterMode;
    texDesc.addressMode[0] = addressMode;
    texDesc.addressMode[1] = addressMode;
    texDesc.addressMode[2] = addressMode;
    
    cudaTextureObject_t texObj;
    err = cudaCreateTextureObject(&texObj, &resDesc, &texDesc, NULL);
    if (err != cudaSuccess) {
        printf("Error: cudaCreateTextureObject failed: %s\n", cudaGetErrorString(err));
        cudaFree(unifiedData);
        cudaFreeArray(devArray);
        return 0;
    }
    
    // Free unified memory
    cudaFree(unifiedData);
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    if (rtdVerboseEnabled()) {
        printf("[TIMING] create3DTexture (unified memory): %ld μs\n", duration.count());
    }
    
    return texObj;
}
