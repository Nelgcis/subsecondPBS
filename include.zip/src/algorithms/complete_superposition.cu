#include "../include/algorithms/superposition.h"
#include "../include/utils/debug_tools.h"

#include <vector>
#include <iostream>
#include <algorithm>
#include <climits>
#include <string>
#include <cuda_runtime.h>

namespace {
constexpr int kMaxSuperpR = MAX_SUPERP_RADIUS;
constexpr int kSuperpTileX = SUPERP_TILE_X;
constexpr int kSuperpTileY = SUPERP_TILE_Y;
// Reference uses 4 and assumes SUPERP_TILE_Y % blockY == 0
constexpr int kTileRadBlockY = 4;
bool rtdSuperpOverflowDebugEnabled() {
    const char* v = std::getenv("RTD_SUPERP_OVERFLOW_DEBUG");
    if (!v) return false;
    const std::string s(v);
    return !(s == "0" || s == "false" || s == "FALSE" || s == "off" || s == "OFF");
}

#define LAUNCH_SUPERP_KERNEL(R) \
    if (batchedPrimTileRadCtrs[R] > 0) { \
        kernelSuperposition<R><<<batchedPrimTileRadCtrs[R], superpBlockDim>>>( \
            devRayIdd, devRayRSigmaEff, devBevPrimDose, rayDimsX, devPrimInOutIdcs, maxNoPrimTiles, devTilePrimRadCtrs); \
    }

struct TileOverflowDebug {
    int z = -1;
    int tileX = -1;
    int tileY = -1;
    float minRSigmaEff = INF;
    float minFiniteRSigmaEff = INF;
    float maxFiniteRSigmaEff = 0.0f;
    float approxMaxSigma = 0.0f;
    float approxMinSigma = 0.0f;
    int finiteCount = 0;
    int infCount = 0;
    int nanCount = 0;
    int belowThresholdCount = 0;
    int positiveIddCount = 0;
    float maxIdd = 0.0f;
};

inline TileOverflowDebug inspectOverflowTile(const float* devRayRSigmaEff,
                                             const float* devRayIdd,
                                             int rayDimsX,
                                             int rayDimsY,
                                             int inIdx,
                                             float threshold) {
    TileOverflowDebug dbg;
    const int slicePitch = rayDimsX * rayDimsY;
    dbg.z = inIdx / slicePitch;
    const int rem = inIdx - dbg.z * slicePitch;
    const int y0 = rem / rayDimsX;
    const int x0 = rem - y0 * rayDimsX;
    dbg.tileX = x0 / kSuperpTileX;
    dbg.tileY = y0 / kSuperpTileY;

    std::vector<float> sigmaRow(kSuperpTileX, INF);
    std::vector<float> iddRow(kSuperpTileX, 0.0f);
    for (int row = 0; row < kSuperpTileY; ++row) {
        const int rowIdx = dbg.z * slicePitch + (y0 + row) * rayDimsX + x0;
        checkCudaErrors(cudaMemcpy(sigmaRow.data(),
                                   devRayRSigmaEff + rowIdx,
                                   kSuperpTileX * sizeof(float),
                                   cudaMemcpyDeviceToHost));
        checkCudaErrors(cudaMemcpy(iddRow.data(),
                                   devRayIdd + rowIdx,
                                   kSuperpTileX * sizeof(float),
                                   cudaMemcpyDeviceToHost));
        for (int col = 0; col < kSuperpTileX; ++col) {
            const float sig = sigmaRow[col];
            const float idd = iddRow[col];
            if (sig < dbg.minRSigmaEff) dbg.minRSigmaEff = sig;
            if (std::isnan(sig)) {
                dbg.nanCount++;
            } else if (!std::isfinite(sig)) {
                dbg.infCount++;
            } else {
                dbg.finiteCount++;
                if (sig < dbg.minFiniteRSigmaEff) dbg.minFiniteRSigmaEff = sig;
                if (sig > dbg.maxFiniteRSigmaEff) dbg.maxFiniteRSigmaEff = sig;
                if (sig < threshold) dbg.belowThresholdCount++;
            }
            if (idd > 0.0f) {
                dbg.positiveIddCount++;
                if (idd > dbg.maxIdd) dbg.maxIdd = idd;
            }
        }
    }
    if (dbg.minFiniteRSigmaEff == INF) dbg.minFiniteRSigmaEff = 0.0f;
    if (dbg.minFiniteRSigmaEff > 0.0f) {
        dbg.approxMaxSigma = rsqrtf(2.0f) / dbg.minFiniteRSigmaEff;
    }
    if (dbg.maxFiniteRSigmaEff > 0.0f) {
        dbg.approxMinSigma = rsqrtf(2.0f) / dbg.maxFiniteRSigmaEff;
    }
    return dbg;
}
} // namespace

// -----------------------------------------------------------------------------
// sliceMinVar / sliceMaxVar
// -----------------------------------------------------------------------------
// NOTE: The reduction is applied per Z-slice. Each blockIdx.z selects one slice.
template<typename T, int blockSize>
__global__ void sliceMinVar(T* const devIn, T* const devOut, const int n) {
    __shared__ T sdata[blockSize];

    const int tid = threadIdx.x;
    const int base = n * blockIdx.z;  // offset to this slice
    int idx = base + tid;

    // Initialize with a large value
    T myMin = (T)INT_MAX;

    // Stride across the slice
    while (idx < base + n) {
        T v = devIn[idx];
        if (v < myMin) myMin = v;
        idx += blockSize;
    }

    sdata[tid] = myMin;
    __syncthreads();

    // Reduce within the block
    for (int s = blockSize / 2; s > 0; s >>= 1) {
        if (tid < s) {
            T other = sdata[tid + s];
            if (other < sdata[tid]) sdata[tid] = other;
        }
        __syncthreads();
    }

    if (tid == 0) {
        devOut[blockIdx.z] = sdata[0];
    }
}

template<typename T, int blockSize>
__global__ void sliceMaxVar(T* const devIn, T* const devOut, const int n) {
    __shared__ T sdata[blockSize];

    const int tid = threadIdx.x;
    const int base = n * blockIdx.z;  // offset to this slice
    int idx = base + tid;

    // Initialize with a small value
    T myMax = (T)INT_MIN;

    // Stride across the slice
    while (idx < base + n) {
        T v = devIn[idx];
        if (v > myMax) myMax = v;
        idx += blockSize;
    }

    sdata[tid] = myMax;
    __syncthreads();

    // Reduce within the block
    for (int s = blockSize / 2; s > 0; s >>= 1) {
        if (tid < s) {
            T other = sdata[tid + s];
            if (other > sdata[tid]) sdata[tid] = other;
        }
        __syncthreads();
    }

    if (tid == 0) {
        devOut[blockIdx.z] = sdata[0];
    }
}

// Explicit template instantiations for int with blockSize=1024
template __global__ void sliceMinVar<int, 1024>(int* const, int* const, const int);
template __global__ void sliceMaxVar<int, 1024>(int* const, int* const, const int);
// Explicit template instantiation needed for WEPL min-reduction (per-step)
template __global__ void sliceMinVar<float, 128>(float* const, float* const, const int);


// -----------------------------------------------------------------------------
// Complete Tile-Based Superposition (RayTraceDicom reference implementation)
// -----------------------------------------------------------------------------
// IMPORTANT: This implementation assumes:
//   - rayDimsX % SUPERP_TILE_X == 0
//   - rayDimsY % SUPERP_TILE_Y == 0
// The wrapper pads (IDD, rSigmaEff) arrays accordingly.
//
// tileRadCalc computes, for each (tile, z), the required radius bucket and stores
// (inIdx, outIdx) pairs in inOutIdcs arranged as [rad][tileIdxWithinRad].
// -----------------------------------------------------------------------------
template<unsigned int blockY>
__global__ void tileRadCalc(float const* __restrict__ devIn,
                            const int startZ,
                            int* const tilePrimRadCtrs,
                            int2* const inOutIdcs,
                            const int noTiles) {
    __shared__ float tile[kSuperpTileX * blockY];

    const int tileIdx = kSuperpTileX * threadIdx.y + threadIdx.x;
    const int pitch = gridDim.x * kSuperpTileX;
    const int inIdx =
        (startZ + blockIdx.z) * (gridDim.y * kSuperpTileY * pitch) +
        (blockIdx.y * kSuperpTileY + threadIdx.y) * pitch +
        blockIdx.x * kSuperpTileX + threadIdx.x;

    // One block per tile. Each thread scans superpTileY/blockY rows and reduces.
    float minVal = devIn[inIdx];
#pragma unroll
    for (int i = 1; i < (kSuperpTileY / blockY); ++i) {
        const int idx = inIdx + i * blockY * pitch;
        const float testVal = devIn[idx];
        if (testVal < minVal) { minVal = testVal; }
    }
    tile[tileIdx] = minVal;
    __syncthreads();

    // Reduction over y
    for (int maxIdxY = blockY / 2; maxIdxY > 0; maxIdxY >>= 1) {
        if (threadIdx.y < maxIdxY && tile[tileIdx + maxIdxY * kSuperpTileX] < tile[tileIdx]) {
            tile[tileIdx] = tile[tileIdx + maxIdxY * kSuperpTileX];
        }
        __syncthreads();
    }

    // Reduction over x (only y==0 threads participate)
    if (threadIdx.y == 0) {
        for (int maxIdxX = kSuperpTileX / 2; maxIdxX > 0; maxIdxX >>= 1) {
            if (threadIdx.x < maxIdxX && tile[threadIdx.x + maxIdxX] < tile[threadIdx.x]) {
                tile[threadIdx.x] = tile[threadIdx.x + maxIdxX];
            }
            __syncthreads();
        }

        if (threadIdx.x == 0) {
            // Calc rad, atomically increment corresponding counter, and write indices and pitches
            int rad = min(int(KS_SIGMA_CUTOFF / (sqrtf(2.0f) * tile[0]) + HALF), kMaxSuperpR + 1);
            int radIdx = atomicAdd(tilePrimRadCtrs + rad, 1);

            const int outIdx =
                (startZ + blockIdx.z) *
                    ((gridDim.y * kSuperpTileY + 2 * kMaxSuperpR) *
                     (gridDim.x * kSuperpTileX + 2 * kMaxSuperpR)) +
                (blockIdx.y * kSuperpTileY) * (gridDim.x * kSuperpTileX + 2 * kMaxSuperpR) +
                blockIdx.x * kSuperpTileX;

            inOutIdcs[rad * noTiles + radIdx] = make_int2(inIdx, outIdx);
        }
    }
}

/**
 * \brief Tile-based kernel superposition (RayTraceDicom reference implementation)
 *
 * NOTE:
 *   - blockDim.x must be SUPERP_TILE_X
 *   - blockDim.y must divide SUPERP_TILE_Y (we use SUPERP_TILE_Y)
 */
template <int rad>
__global__ void kernelSuperposition(float const* __restrict__ inDose,
                                    float const* __restrict__ inRSigmaEff,
                                    float* const outDose,
                                    const int inDosePitch,
                                    int2* const inOutIdcs,
                                    const int inOutIdxPitch,
                                    int* const tileCtrs) {
    volatile __shared__ float tile[(kSuperpTileX + 2 * rad) * (kSuperpTileY + 2 * rad)];

    // Clear shared tile buffer
    for (int i = threadIdx.y * blockDim.x + threadIdx.x;
         i < (kSuperpTileY + 2 * rad) * (kSuperpTileX + 2 * rad);
         i += blockDim.x * blockDim.y) {
        tile[i] = 0.0f;
    }
    __syncthreads();

    int tileIdx = blockIdx.x;
    int radIdx = rad;
    while (tileIdx >= tileCtrs[radIdx]) {
        tileIdx -= tileCtrs[radIdx];
        radIdx -= 1;
    }

    // __syncthreads inside this block requires that blockDim.y divides superpTileY
    for (int row = threadIdx.y; row < kSuperpTileY; row += blockDim.y) {
        int inIdx = inOutIdcs[radIdx * inOutIdxPitch + tileIdx].x +
                    row * inDosePitch + threadIdx.x;

        float dose = inDose[inIdx];

        if (__syncthreads_or(dose > 0.0f)) {
            float rSigmaEff = inRSigmaEff[inIdx];
            float erfNew = erff(rSigmaEff * HALF);
            float erfOld = -erfNew;
            float erfDiffs[rad + 1];

#pragma unroll
            for (int i = 0; i <= rad; ++i) {
                erfDiffs[i] = HALF * (erfNew - erfOld);
                erfOld = erfNew;
                erfNew = erff(rSigmaEff * (float(i) + 1.5f));
            }

#pragma unroll
            for (int i = 0; i < 2 * rad + 1; ++i) {
#pragma unroll
                for (int j = 0; j < 2 * rad + 1; ++j) {
                    tile[(row + i) * (kSuperpTileX + 2 * rad) + threadIdx.x + j] +=
                        dose * erfDiffs[abs(rad - i)] * erfDiffs[abs(rad - j)];
                }
                __syncthreads(); // Must not be inside a conditional branch
            }
        }
    }

    for (int row = threadIdx.y - rad + kMaxSuperpR;
         row < kSuperpTileY + rad + kMaxSuperpR;
         row += blockDim.y) {
        for (int col = threadIdx.x - rad + kMaxSuperpR;
             col < kSuperpTileX + rad + kMaxSuperpR;
             col += kSuperpTileX) {
            int outPitch = inDosePitch + 2 * kMaxSuperpR;
            int outIdx = inOutIdcs[radIdx * inOutIdxPitch + tileIdx].y +
                         row * outPitch + col;
            atomicAdd(outDose + outIdx,
                      tile[(row + rad - kMaxSuperpR) * (kSuperpTileX + 2 * rad) +
                           col + rad - kMaxSuperpR]);
        }
    }
}

void performCompleteTileBasedSuperposition(float* devRayIdd,
                                          float* devRayRSigmaEff,
                                          float* devBevPrimDose,
                                          int rayDimsX,
                                          int rayDimsY,
                                          int steps,
                                          int beamFirstInside,
                                          int beamFirstCalculatedPassive) {
    GPU_TIMER_START();

    if (beamFirstCalculatedPassive <= beamFirstInside) {
        std::cerr << "Warning: beamFirstCalculatedPassive <= beamFirstInside, skipping superposition\n";
        return;
    }

    // This function assumes padded ray dims; enforce to avoid silent misindexing.
    if (rayDimsX % kSuperpTileX != 0 || rayDimsY % kSuperpTileY != 0) {
        std::cerr << "Error: Ray dimensions must be multiples of superposition tile size.\n"
                  << "  rayDims: (" << rayDimsX << ", " << rayDimsY << ")\n"
                  << "  tile: (" << kSuperpTileX << ", " << kSuperpTileY << ")\n";
        return;
    }

    const int numTilesX = rayDimsX / kSuperpTileX;
    const int numTilesY = rayDimsY / kSuperpTileY;
    const int numStepsInside = beamFirstCalculatedPassive - beamFirstInside;

    const int maxNoPrimTiles = numStepsInside * numTilesX * numTilesY;

    // Allocate counters and index buffer
    int* devTilePrimRadCtrs = nullptr;
    int2* devPrimInOutIdcs = nullptr;

    checkCudaErrors(cudaMalloc(&devTilePrimRadCtrs, (kMaxSuperpR + 2) * sizeof(int)));
    checkCudaErrors(cudaMalloc(&devPrimInOutIdcs, (kMaxSuperpR + 2) * maxNoPrimTiles * sizeof(int2)));

    // Reset counters
    checkCudaErrors(cudaMemset(devTilePrimRadCtrs, 0, (kMaxSuperpR + 2) * sizeof(int)));

    // Launch tile radius calculation
    const dim3 tileRadGridDim(numTilesX, numTilesY, numStepsInside);
    const dim3 tileRadBlockDim(kSuperpTileX, kTileRadBlockY);

    tileRadCalc<kTileRadBlockY><<<tileRadGridDim, tileRadBlockDim>>>(
        devRayRSigmaEff, beamFirstInside, devTilePrimRadCtrs, devPrimInOutIdcs, maxNoPrimTiles);
    checkCudaErrors(cudaDeviceSynchronize());

    // Copy tile counters back to host
    std::vector<int> tilePrimRadCtrs(kMaxSuperpR + 2, 0);
    checkCudaErrors(cudaMemcpy(tilePrimRadCtrs.data(),
                               devTilePrimRadCtrs,
                               (kMaxSuperpR + 2) * sizeof(int),
                               cudaMemcpyDeviceToHost));

    if (tilePrimRadCtrs[kMaxSuperpR + 1] > 0) {
        const int overflowCount = tilePrimRadCtrs[kMaxSuperpR + 1];
        const int maxBucketBase = tilePrimRadCtrs[kMaxSuperpR];
        const float overflowThreshold = KS_SIGMA_CUTOFF / (sqrtf(2.0f) * (float(kMaxSuperpR) + 0.5f));
        
        // [9.44 Halo Overflow Gate]
        // When radius exceeds kMaxSuperpR, the current code clamps to kMaxSuperpR.
        // For primary dose this may be acceptable with proper edge falloff documentation.
        // For halo (nuclear), this is HIGH RISK: nuclear sigma is typically wider than primary;
        // overflow clamp causes system-atic loss of lateral tails, changing dose profile shape.
        // TODO: Implement upstream overflow semantics (per RayTraceDicom-main branch)
        //       or convert to fail-fast gate for halo-on runs with large sigma.
        
        std::cerr << "Warning: Superposition required radius larger than max radius; clamping to max radius\n"
                  << "  maxRadius=" << kMaxSuperpR
                  << " overflowTiles=" << overflowCount
                  << " threshold_rSigmaEff<" << overflowThreshold
                  << "\n  NOTE [9.44]: For nuclear halo runs, this clamp may introduce non-physical tail truncation."
                  << std::endl;
        const int sampleCount = rtdSuperpOverflowDebugEnabled() ? std::min(overflowCount, 4) : 0;
        if (sampleCount > 0) {
            std::vector<int2> overflowSamples(sampleCount);
            checkCudaErrors(cudaMemcpy(overflowSamples.data(),
                                       devPrimInOutIdcs + (kMaxSuperpR + 1) * maxNoPrimTiles,
                                       sampleCount * sizeof(int2),
                                       cudaMemcpyDeviceToHost));
            for (int i = 0; i < sampleCount; ++i) {
                const TileOverflowDebug dbg = inspectOverflowTile(
                    devRayRSigmaEff, devRayIdd, rayDimsX, rayDimsY, overflowSamples[i].x, overflowThreshold);
                std::cerr << "  overflowSample[" << i << "]"
                          << " z=" << dbg.z
                          << " tile=(" << dbg.tileX << "," << dbg.tileY << ")"
                          << " minRSigmaEff=" << dbg.minRSigmaEff
                          << " minFiniteRSigmaEff=" << dbg.minFiniteRSigmaEff
                          << " maxFiniteRSigmaEff=" << dbg.maxFiniteRSigmaEff
                          << " approxSigmaRange=[" << dbg.approxMinSigma << "," << dbg.approxMaxSigma << "]"
                          << " finite=" << dbg.finiteCount
                          << " inf=" << dbg.infCount
                          << " nan=" << dbg.nanCount
                          << " belowThreshold=" << dbg.belowThresholdCount
                          << " positiveIdd=" << dbg.positiveIddCount
                          << " maxIdd=" << dbg.maxIdd
                          << std::endl;
            }
        }

        // MODIFIED: Carbon profile sigmas can exceed the proton-era RTD max kernel
        // radius. Clamp these tiles into the max-radius bucket instead of dropping
        // the whole layer, so the main path stays connected and only the tails are clipped.
        checkCudaErrors(cudaMemcpy(
            devPrimInOutIdcs + kMaxSuperpR * maxNoPrimTiles + maxBucketBase,
            devPrimInOutIdcs + (kMaxSuperpR + 1) * maxNoPrimTiles,
            overflowCount * sizeof(int2),
            cudaMemcpyDeviceToDevice));
        tilePrimRadCtrs[kMaxSuperpR] += overflowCount;
        tilePrimRadCtrs[kMaxSuperpR + 1] = 0;
        checkCudaErrors(cudaMemcpy(devTilePrimRadCtrs,
                                   tilePrimRadCtrs.data(),
                                   (kMaxSuperpR + 2) * sizeof(int),
                                   cudaMemcpyHostToDevice));
    }

    int layerMaxPrimSuperpR = 0;
    for (int i = 0; i < kMaxSuperpR + 2; ++i) {
        if (tilePrimRadCtrs[i] > 0) { layerMaxPrimSuperpR = i; }
    }

    int totalTiles = 0;
    for (int rad = 0; rad <= kMaxSuperpR; ++rad) totalTiles += tilePrimRadCtrs[rad];

    if (rtdVerboseEnabled()) {
        std::cout << "  Superposition tile summary: totalTiles=" << totalTiles
                  << ", layerMaxPrimSuperpR=" << layerMaxPrimSuperpR
                  << ", rad0=" << tilePrimRadCtrs[0]
                  << ", rad1=" << tilePrimRadCtrs[1]
                  << ", rad2=" << tilePrimRadCtrs[2]
                  << std::endl;
    }

    // Batch tile counts (reference behavior)
    std::vector<int> batchedPrimTileRadCtrs(kMaxSuperpR + 1, 0);
    batchedPrimTileRadCtrs[0] = tilePrimRadCtrs[0];

    int recPrimRad = layerMaxPrimSuperpR;
    for (int rad = layerMaxPrimSuperpR; rad > 0; --rad) {
        batchedPrimTileRadCtrs[recPrimRad] += tilePrimRadCtrs[rad];
        if (batchedPrimTileRadCtrs[recPrimRad] >= MIN_TILES_IN_BATCH) {
            recPrimRad = rad - 1;
        }
    }

    if (rtdVerboseEnabled()) {
        std::cout << "  Superposition batched launches:";
        for (int r = 0; r <= layerMaxPrimSuperpR; ++r) {
            if (batchedPrimTileRadCtrs[r] > 0) {
                std::cout << " [rad=" << r << ":" << batchedPrimTileRadCtrs[r] << "]";
            }
        }
        std::cout << std::endl;
    }

    const dim3 superpBlockDim(kSuperpTileX, kSuperpTileY);

    // Launch batched kernel superposition for each radius bucket (0..MAX_SUPERP_RADIUS)
    LAUNCH_SUPERP_KERNEL(0);
    LAUNCH_SUPERP_KERNEL(1);
    LAUNCH_SUPERP_KERNEL(2);
    LAUNCH_SUPERP_KERNEL(3);
    LAUNCH_SUPERP_KERNEL(4);
    LAUNCH_SUPERP_KERNEL(5);
    LAUNCH_SUPERP_KERNEL(6);
    LAUNCH_SUPERP_KERNEL(7);
    LAUNCH_SUPERP_KERNEL(8);
    LAUNCH_SUPERP_KERNEL(9);
    LAUNCH_SUPERP_KERNEL(10);
    LAUNCH_SUPERP_KERNEL(11);
    LAUNCH_SUPERP_KERNEL(12);
    LAUNCH_SUPERP_KERNEL(13);
    LAUNCH_SUPERP_KERNEL(14);
    LAUNCH_SUPERP_KERNEL(15);
    LAUNCH_SUPERP_KERNEL(16);
    LAUNCH_SUPERP_KERNEL(17);
    LAUNCH_SUPERP_KERNEL(18);
    LAUNCH_SUPERP_KERNEL(19);
    LAUNCH_SUPERP_KERNEL(20);
    LAUNCH_SUPERP_KERNEL(21);
    LAUNCH_SUPERP_KERNEL(22);
    LAUNCH_SUPERP_KERNEL(23);
    LAUNCH_SUPERP_KERNEL(24);
    LAUNCH_SUPERP_KERNEL(25);
    LAUNCH_SUPERP_KERNEL(26);
    LAUNCH_SUPERP_KERNEL(27);
    LAUNCH_SUPERP_KERNEL(28);
    LAUNCH_SUPERP_KERNEL(29);
    LAUNCH_SUPERP_KERNEL(30);
    LAUNCH_SUPERP_KERNEL(31);
    LAUNCH_SUPERP_KERNEL(32);

    checkCudaErrors(cudaDeviceSynchronize());

    // Cleanup
    checkCudaErrors(cudaFree(devTilePrimRadCtrs));
    checkCudaErrors(cudaFree(devPrimInOutIdcs));

    GPU_TIMER_END("Complete Tile-Based Superposition");
}

#undef LAUNCH_SUPERP_KERNEL
